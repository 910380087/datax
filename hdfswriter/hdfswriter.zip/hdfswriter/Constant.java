package com.alibaba.datax.plugin.writer.hdfswriter;

public class Constant {

	public static final String DEFAULT_ENCODING = "UTF-8";
	public static final String DEFAULT_NULL_FORMAT = "\\N";
}
